# GameTracker MERN
See backend/README.md and frontend/README.md for details.

The original user PDF is at assets/proyecto.pdf (local path: /mnt/data/proyecto.pdf)
